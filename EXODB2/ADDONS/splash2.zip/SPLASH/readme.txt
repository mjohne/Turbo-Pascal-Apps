
 SPLASH PACK #2
 ==============


 �ber dieser Archiv
 ------------------

 Bei diesem Ordner handelt es sich um ein Add-On f�r das Programm EXO-DB2.
 Diese Add-On nennt sich "SPLASH PACK #2" und wurde am 12. Juni 2006 ver-
 �ffentlicht.

 "SPLASH PACK #2" beinhaltet 20 neue Splash Screens und ersetzt die Standard-
 Splash Screen-Anzeige von EXO-DB2 1.7. Wenn dieses Add-On installiert ist,
 wird dabei mit jedem Neustart von EXO-DB2 1.7 ein neuer Splash Screen zu-
 fallsm��ig angezeigt.

 "SPLASH PACK #2" ist f�r EXO-DB2 ab Version 1.7 bestimmt und wird ab dieser
 Version automatisch erkannt. Dieses Add-On beinhaltet 20 neue Splash Screens,
 die einen Speicher von 812 KByte belegen. Folgende Dateien enth�lt das Archiv:

          MD5-Summe                 Dateiname   Gr��e in Bytes
 -------------------------------------------------------------
 8ade850af98b3ac0131c0df31e17f887 *TITLE21.LZS      32426
 d5e1b9b63d19febcb397c968c52f46e0 *TITLE22.LZS      34200
 da1831d3fb416a6f34ce546f1a5c1c19 *TITLE23.LZS      36703
 23543361fe0d28a93dbd5f2a69d9aeb6 *TITLE24.LZS      43025
 2c3a77a18cf73a3098526dfecb0571c5 *TITLE25.LZS      42740
 b2b6e33c3542a1b9aa13971822d994fc *TITLE26.LZS      30596
 b39ded814820ce8f42fa8921fd3e2ee7 *TITLE27.LZS      44079
 ea330a5791523e13866df1a434c37846 *TITLE28.LZS      45092
 bf714cb91309b17ee3238095b7930a29 *TITLE29.LZS      47687
 1a2037a244d16cbc7e371da118b12ff6 *TITLE30.LZS      57859
 a52b0bcb9a0b7063df1d3a5a27f360ad *TITLE31.LZS      44221
 c78a44b52815b9740852f56eadc687dd *TITLE32.LZS      59331
 acdc64503e7b479726d3acaf73a2492b *TITLE33.LZS      53207
 f9ef6642d4596632d73a5267211ddd97 *TITLE34.LZS      33234
 bd07e6e9e366938d6c191c696d9eac59 *TITLE35.LZS      33341
 ddc1f414ddee8bc6f3abda7f09403042 *TITLE36.LZS      40270
 4f4aa976ffc9b258af1806c50613b0c5 *TITLE37.LZS      38703
 c3c0b31d3f38f7c2538d7e6f6c419d5c *TITLE38.LZS      42425
 42dfbd107f5a39d843c1f5f31729e6cc *TITLE39.LZS      40974
 76bf5f728ec5df29a55e1b4d3a14602b *TITLE40.LZS      32043



 Installation:
 -------------

 1. Entpacken Sie das Archiv!
    Dort sollte sich das Verzeichnis /SPLASH/ mitsamt allen LZS-Dateien be-
    finden! Achten Sie aber darauf, dass Ihr Packer KEIN zus�tzlich dop-
    peltes Verzeichnis nach folgendem Muster erstellt:
    "/SPLASH/SPLASH/*.lzs"

 2. Kopieren Sie das Verzeichnis /SPLASH/ in das Stammverzeichnis von EXO-DB2
    Ihrer benutzten Version hinein!

 3. Am Ende sollten Sie EXO-DB2 neu starten und nachschauen, dass und ob
    alles funktioniert und stets ein neuer Splash Screen zu jedem Programm-
    start angezeigt wird!
    EXO-DB2 1.7 und alle nachfolgenden Versionen erkennen dieses Add-On
    automatisch.

 4. Sollten Sie dennoch Probleme bei der Installation des Add-Ons haben,
    dann mailen Sie mir unter <michael-johne@gmx.de> mit einer m�glichst
    genauen Problembeschreibung. Ihre Mail wird dann im Rahmen des zeit-
    lichen Machbaren mit einer L�sung beantwortet.


 Deinstallation:
 ---------------
 
 Falls man die Anzeige des Splash-Screens aus bestimmten Gr�nden unterbinden
 m�chten, geht man folgenderma�en vor:

 1. L�schen Sie die Datei "splash.dat". Diese Datei unterbindet dann die An-
    zeige des Splash Screens komplett.

 2. Zus�tzlich k�nnen Sie auch die Datei "splash.pic" l�schen, wenn Sie auf
    Dauer keine Anzeige des Splash-Screens mehr haben m�chten.

 3. Falls Sie das Add-On "Splash Pack #2" installiert haben, k�nnen Sie den
    Unterordner "SPLASH" mitsamt allen LZS-Dateien einfach l�schen.
