
 SPLASH PACK #1
 ==============


 �ber dieser Archiv
 ------------------

 Bei diesem Ordner handelt es sich um ein Add-On f�r das Programm EXO-DB2.
 Diese Add-On nennt sich "SPLASH PACK #1" und wurde am 18. April 2006 ver-
 �ffentlicht.

 "SPLASH PACK #1" beinhaltet 20 neue Splash Screens und ersetzt die Standard-
 Splash Screen-Anzeige von EXO-DB2 1.7. Wenn dieses Add-On installiert ist,
 wird dabei mit jedem Neustart von EXO-DB2 1.7 ein neuer Splash Screen zu-
 fallsm��ig angezeigt.

 "SPLASH PACK #1" ist f�r EXO-DB2 ab Version 1.7 bestimmt und wird ab dieser
 Version automatisch erkannt. Dieses Add-On beinhaltet 20 neue Splash Screens,
 die einen Speicher von 735 KByte belegen. Folgende Dateien enth�lt das Archiv:

          MD5-Summe                 Dateiname   Gr��e in Bytes
 -------------------------------------------------------------
 3261bf1eba1e84a315af13bb93e701a0 *TITLE01.LZS      36911
 3572411c328fb0d6e3ee9ca1abcdb6b0 *TITLE02.LZS      39751
 6df67c8ff5dc4dc5fc46291b2253177d *TITLE03.LZS      33082
 1428c2565016531dc7bfe3c46e0a017f *TITLE04.LZS      29282
 aab8b964ee91f213d45abd35d019bf58 *TITLE05.LZS      43910
 514c67d01a7f9c011239597081eea255 *TITLE06.LZS      26604
 6046f5410e7edadf5eb8970c149b42fb *TITLE07.LZS      41890
 329a58fd14c310c72d6c446f5a0c1494 *TITLE08.LZS      28416
 884d29498260583227976827cd6b313a *TITLE09.LZS      52102
 15e10618e97a18a5f33be79d94c438ad *TITLE10.LZS      40946
 9826582268f001cc703fb4d8135e1efb *TITLE11.LZS      52735
 2a1a22f6816783084b156971880f0caa *TITLE12.LZS      48093
 25d7f50de6c59eb5c30f42a20dbad01d *TITLE13.LZS      24322
 a679d73ab617ded2115494dce8bdcf71 *TITLE14.LZS      35686
 a058e790b13a323213bf08f8dd26ee51 *TITLE15.LZS      50610
 5541596240e125d7e3fc3f99c17d4bf4 *TITLE16.LZS      32027
 162ada255795f416725cc39d4f60db68 *TITLE17.LZS      38131
 6a5efaf012aea569b6efeb8b4cff25a0 *TITLE18.LZS      30744
 d0bec89ff1a5d401b0ca1fd91b48e843 *TITLE19.LZS      26170
 d06ffc3512a03faaec144cb15332c296 *TITLE20.LZS      41829


 Installation:
 -------------

 1. Entpacken Sie das Archiv!
    Dort sollte sich das Verzeichnis /SPLASH/ mitsamt allen LZS-Dateien be-
    finden! Achten Sie aber darauf, dass Ihr Packer KEIN zus�tzlich dop-
    peltes Verzeichnis nach folgendem Muster erstellt:
    "/SPLASH/SPLASH/*.lzs"

 2. Kopieren Sie das Verzeichnis /SPLASH/ in das Stammverzeichnis von EXO-DB2
    Ihrer benutzten Version hinein!

 3. Am Ende sollten Sie EXO-DB2 neu starten und nachschauen, dass und ob
    alles funktioniert und stets ein neuer Splash Screen zu jedem Programm-
    start angezeigt wird!
    EXO-DB2 1.7 und alle nachfolgenden Versionen erkennen dieses Add-On
    automatisch.

 4. Sollten Sie dennoch Probleme bei der Installation des Add-Ons haben,
    dann mailen Sie mir unter <michael-johne@gmx.de> mit einer m�glichst
    genauen Problembeschreibung. Ihre Mail wird dann im Rahmen des zeit-
    lichen Machbaren mit einer L�sung beantwortet.


 Deinstallation:
 ---------------
 
 Falls man die Anzeige des Splash-Screens aus bestimmten Gr�nden unterbinden
 m�chten, geht man folgenderma�en vor:

 1. L�schen Sie die Datei "splash.dat". Diese Datei unterbindet dann die An-
    zeige der Splash Screen komplett.

 2. Zus�tzlich k�nnen Sie auch die Datei "splash.pic" l�schen, wenn Sie auf
    Dauer keine Anzeige des Splash-Screens mehr haben m�chten.

 3. Falls Sie das Add-On "Splash Pack #1" installiert haben, k�nnen Sie den
    Unterordner "SPLASH" mitsamt allen LZS-Dateien einfach l�schen.
